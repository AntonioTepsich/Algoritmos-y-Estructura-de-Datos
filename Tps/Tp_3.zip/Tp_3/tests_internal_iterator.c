#include "test_malloc.h"
#include "testing.h"
#include "internal_iterator.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Acá implementa tus tests

int main_internal_iterator(void) {
  srand(117);
  int return_code = 0;
  return_code += 1; // Agrega tus propios tests acá
  exit(return_code);
}
